
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend("re_GfqG1H8y_7FWDDseqcmXYVjMomv1CPFaT");

// Define CORS headers for browser access
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AppointmentEmailRequest {
  patientName: string;
  patientEmail: string;
  doctorName: string;
  appointmentDate: string;
  appointmentTime: string;
  specialty: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      patientName, 
      patientEmail, 
      doctorName, 
      appointmentDate, 
      appointmentTime, 
      specialty 
    }: AppointmentEmailRequest = await req.json();

    // Validate required fields
    if (!patientName || !patientEmail || !doctorName || !appointmentDate || !appointmentTime) {
      return new Response(
        JSON.stringify({ error: "Missing required fields for email" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Sending appointment confirmation to: ${patientEmail}`);

    const emailResponse = await resend.emails.send({
      from: "HealthAI <onboarding@resend.dev>",
      to: [patientEmail],
      subject: "Your Appointment Confirmation - HealthAI Assistant",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e1e1e1; border-radius: 5px;">
          <div style="background-color: #4F46E5; padding: 15px; border-radius: 5px 5px 0 0;">
            <h2 style="color: white; margin: 0; text-align: center;">Appointment Confirmation</h2>
          </div>
          
          <div style="padding: 20px;">
            <p>Hello ${patientName},</p>
            <p>Your appointment has been successfully scheduled. Here are the details:</p>
            
            <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <p><strong>Doctor:</strong> ${doctorName}</p>
              <p><strong>Specialty:</strong> ${specialty}</p>
              <p><strong>Date:</strong> ${appointmentDate}</p>
              <p><strong>Time:</strong> ${appointmentTime}</p>
            </div>
            
            <p>If you need to reschedule or cancel your appointment, please contact us at least 24 hours in advance.</p>
            
            <p>Thank you for choosing HealthAI Assistant.</p>
            
            <p>Regards,<br>HealthAI Assistant Team</p>
          </div>
          
          <div style="background-color: #f1f1f1; padding: 10px; text-align: center; font-size: 12px; color: #666; border-radius: 0 0 5px 5px;">
            <p>This is an automated message, please do not reply directly to this email.</p>
          </div>
        </div>
      `,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ success: true, message: "Email sent successfully", id: emailResponse.id }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in send-email function:", error);
    
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred while sending the email" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
