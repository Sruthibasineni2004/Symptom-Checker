
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

// Define CORS headers for browser access
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SymptomRequest {
  symptoms: string;
}

// Function to analyze symptoms using Gemini API
async function analyzeWithGemini(symptoms: string) {
  try {
    console.log("Making request to Gemini API with symptoms:", symptoms);
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCoVqntvMWYzLf1lgUI2r2xMG5FMnzlUfM`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `As a medical AI assistant, analyze these symptoms and provide medically sound advice: "${symptoms}".
                Please structure your response with these sections:
                - Possible Causes
                - Recommendations
                - When to See a Doctor
                
                Start each section with a ** header. Format each point with a • bullet point.
                Include a disclaimer at the end reminding that this is AI-generated advice and not a replacement for professional medical consultation.`,
              }
            ],
          }
        ],
        generationConfig: {
          temperature: 0.2,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 1024,
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
        ],
      }),
    });

    const data = await response.json();
    console.log("Gemini API Response:", JSON.stringify(data, null, 2));

    // Check if there's an error in the response
    if (data.error) {
      throw new Error(`Gemini API Error: ${data.error.message}`);
    }

    // Extract the text from the response
    if (data.candidates && data.candidates[0]?.content?.parts && data.candidates[0]?.content?.parts[0]?.text) {
      return data.candidates[0].content.parts[0].text;
    } else {
      throw new Error("Unexpected API response format - no content found");
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { symptoms }: SymptomRequest = await req.json();
    
    if (!symptoms || typeof symptoms !== "string") {
      return new Response(
        JSON.stringify({ error: "Invalid request. 'symptoms' field is required and must be a string." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Analyzing symptoms:", symptoms);
    const analysis = await analyzeWithGemini(symptoms);

    return new Response(
      JSON.stringify({ analysis }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in analyze-symptoms function:", error);
    
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred during symptom analysis" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
