
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Stethoscope, Brain, User, Sun, Moon, BarChart3, Users } from 'lucide-react';
import SymptomForm from '@/components/SymptomForm';
import ProfileSection from '@/components/ProfileSection';
import RoleBasedAuth from '@/components/RoleBasedAuth';
import HealthInsights from '@/components/HealthInsights';
import DoctorDashboard from '@/components/DoctorDashboard';
import IndianDoctors from '@/components/IndianDoctors';
import { supabase } from '@/integrations/supabase/client';
import { Session } from '@supabase/supabase-js';

const Index = () => {
  const [activeTab, setActiveTab] = useState('symptoms');
  const [darkMode, setDarkMode] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const [userRole, setUserRole] = useState<string>('patient');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        if (session?.user?.user_metadata?.role) {
          setUserRole(session.user.user_metadata.role);
        }
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user?.user_metadata?.role) {
        setUserRole(session.user.user_metadata.role);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  const handleAuth = (user: any, role: string) => {
    setUserRole(role);
    setActiveTab(role === 'doctor' ? 'doctor-dashboard' : 'symptoms');
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUserRole('patient');
    setActiveTab('symptoms');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark bg-gray-900' : 'bg-gradient-to-br from-blue-50 to-indigo-100'}`}>
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-blue-100 dark:border-gray-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <div className="flex items-center space-x-3">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Stethoscope className="h-6 w-6 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">HealthAI Assistant</h1>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleDarkMode}
                className="p-2"
              >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex items-center justify-center min-h-[calc(100vh-80px)] px-4">
          <RoleBasedAuth onAuth={handleAuth} darkMode={darkMode} />
        </main>
      </div>
    );
  }

  // Define navigation items based on user role
  const getNavigationItems = () => {
    const baseItems = [
      { id: 'profile', icon: User, label: 'Profile & History' }
    ];

    if (userRole === 'doctor') {
      return [
        { id: 'doctor-dashboard', icon: Users, label: 'Dashboard' },
        ...baseItems
      ];
    }

    if (userRole === 'admin') {
      return [
        { id: 'symptoms', icon: Brain, label: 'Symptom Analysis' },
        { id: 'indian-doctors', icon: Stethoscope, label: 'Book with Doctors' },
        { id: 'insights', icon: BarChart3, label: 'Health Insights' },
        { id: 'doctor-dashboard', icon: Users, label: 'Doctor Dashboard' },
        ...baseItems
      ];
    }

    // Patient role
    return [
      { id: 'symptoms', icon: Brain, label: 'Symptom Analysis' },
      { id: 'indian-doctors', icon: Stethoscope, label: 'Book with Doctors' },
      { id: 'insights', icon: BarChart3, label: 'Health Insights' },
      ...baseItems
    ];
  };

  const navigationItems = getNavigationItems();

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark bg-gray-900' : 'bg-gradient-to-br from-blue-50 to-indigo-100'}`}>
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-blue-100 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Stethoscope className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">HealthAI Assistant</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-300 capitalize">
                {userRole}: {session.user.user_metadata?.name || session.user.email}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleDarkMode}
                className="p-2"
              >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="text-gray-600 dark:text-gray-300"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto">
            {navigationItems.map(({ id, icon: Icon, label }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
                  activeTab === id
                    ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'symptoms' && <SymptomForm />}
        {activeTab === 'indian-doctors' && <IndianDoctors />}
        {activeTab === 'insights' && <HealthInsights />}
        {activeTab === 'doctor-dashboard' && <DoctorDashboard />}
        {activeTab === 'profile' && <ProfileSection />}
      </main>
    </div>
  );
};

export default Index;
