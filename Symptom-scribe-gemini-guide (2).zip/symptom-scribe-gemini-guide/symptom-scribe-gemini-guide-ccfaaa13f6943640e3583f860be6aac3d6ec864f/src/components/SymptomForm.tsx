
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Brain, Send, Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

const SymptomForm = () => {
  const [symptoms, setSymptoms] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const { toast } = useToast();

  const analyzeSymptoms = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!symptoms.trim()) return;

    setIsAnalyzing(true);
    
    try {
      // Call the Supabase Edge Function to analyze symptoms
      const { data, error } = await supabase.functions.invoke('analyze-symptoms', {
        body: { symptoms: symptoms.trim() }
      });
      
      if (error) throw error;

      setAnalysis(data.analysis);
      
      // Save the symptom and analysis to the database
      const { data: user } = await supabase.auth.getUser();
      if (user.user) {
        const { error: insertError } = await supabase
          .from('symptoms')
          .insert({
            user_id: user.user.id,
            symptoms: symptoms.trim(),
            analysis: data.analysis,
            severity: 'moderate' // You could add logic to determine severity from the analysis
          });

        if (insertError) {
          console.error('Error saving symptom:', insertError);
        }
      }
      
      toast({
        title: "Analysis Complete!",
        description: "Your symptoms have been analyzed and saved to your history.",
      });
    } catch (error) {
      console.error('Error analyzing symptoms:', error);
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze symptoms. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Symptom Analysis</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Describe your symptoms and get AI-powered health insights
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <Card className="bg-white dark:bg-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-blue-600" />
              <span>Describe Your Symptoms</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={analyzeSymptoms} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="symptoms">What symptoms are you experiencing?</Label>
                <Textarea
                  id="symptoms"
                  placeholder="Please describe your symptoms in detail... (e.g., fever, headache, fatigue for 2 days)"
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  className="min-h-[120px] bg-gray-50 dark:bg-gray-700"
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800"
                disabled={isAnalyzing || !symptoms.trim()}
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Analyze Symptoms
                  </>
                )}
              </Button>
            </form>

            {/* Quick Symptom Examples */}
            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <h4 className="font-medium text-blue-900 dark:text-blue-300 mb-2">Example symptoms:</h4>
              <div className="flex flex-wrap gap-2">
                {[
                  "Headache and fever",
                  "Persistent cough",
                  "Stomach pain",
                  "Fatigue and dizziness"
                ].map((example) => (
                  <Button
                    key={example}
                    variant="ghost"
                    size="sm"
                    onClick={() => setSymptoms(example)}
                    className="text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-800/30"
                  >
                    {example}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Analysis Results */}
        <Card className="bg-white dark:bg-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span>AI Analysis Results</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analysis ? (
              <div className="space-y-4">
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  {analysis.split('\n').map((line, index) => {
                    if (line.startsWith('**') && line.endsWith('**')) {
                      return (
                        <h4 key={index} className="font-semibold text-gray-900 dark:text-white mt-4 mb-2">
                          {line.replace(/\*\*/g, '')}
                        </h4>
                      );
                    }
                    if (line.startsWith('•')) {
                      return (
                        <p key={index} className="text-gray-700 dark:text-gray-300 ml-4">
                          {line}
                        </p>
                      );
                    }
                    return line ? (
                      <p key={index} className="text-gray-700 dark:text-gray-300">
                        {line}
                      </p>
                    ) : null;
                  })}
                </div>
                
                <div className="mt-6 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-amber-800 dark:text-amber-300">Important Notice</h4>
                      <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                        This AI analysis is for informational purposes only and should not replace professional medical advice.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <Brain className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p>Enter your symptoms above to get AI-powered analysis</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SymptomForm;
