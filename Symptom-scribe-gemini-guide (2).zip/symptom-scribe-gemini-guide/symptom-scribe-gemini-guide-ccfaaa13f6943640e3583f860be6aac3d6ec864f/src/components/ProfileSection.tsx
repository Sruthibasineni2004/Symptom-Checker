
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { User, Calendar, Brain, Clock, MapPin, Stethoscope } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface UserProfile {
  id: string;
  name: string | null;
  email: string | null;
  created_at: string;
}

interface Symptom {
  id: string;
  symptoms: string;
  analysis: string | null;
  severity: string | null;
  created_at: string;
}

interface Appointment {
  id: string;
  doctor_name: string;
  specialty: string | null;
  date: string;
  time: string;
  status: string | null;
  created_at: string;
}

const ProfileSection = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [symptoms, setSymptoms] = useState<Symptom[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      // Fetch profile
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.user.id)
        .single();

      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Error fetching profile:', profileError);
      } else {
        setProfile(profileData);
      }

      // Fetch symptoms
      const { data: symptomsData, error: symptomsError } = await supabase
        .from('symptoms')
        .select('*')
        .eq('user_id', user.user.id)
        .order('created_at', { ascending: false });

      if (symptomsError) {
        console.error('Error fetching symptoms:', symptomsError);
      } else {
        setSymptoms(symptomsData || []);
      }

      // Fetch appointments
      const { data: appointmentsData, error: appointmentsError } = await supabase
        .from('appointments')
        .select('*')
        .eq('user_id', user.user.id)
        .order('created_at', { ascending: false });

      if (appointmentsError) {
        console.error('Error fetching appointments:', appointmentsError);
      } else {
        setAppointments(appointmentsData || []);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      toast({
        title: "Error",
        description: "Failed to load profile data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Profile & History</h2>
        <p className="text-gray-600 dark:text-gray-400">
          View your personal information and health history
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Profile Information */}
        <Card className="bg-white dark:bg-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="h-5 w-5 text-blue-600" />
              <span>Profile Information</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Name</label>
              <p className="text-gray-900 dark:text-white">{profile?.name || 'Not provided'}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Email</label>
              <p className="text-gray-900 dark:text-white">{profile?.email}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Member Since</label>
              <p className="text-gray-900 dark:text-white">
                {profile?.created_at ? formatDate(profile.created_at) : 'Unknown'}
              </p>
            </div>
            
            {/* Statistics */}
            <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold text-blue-600">{symptoms.length}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Analyses</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-green-600">{appointments.length}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Appointments</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Symptom History */}
        <Card className="bg-white dark:bg-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-purple-600" />
              <span>Symptom History</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {symptoms.length > 0 ? (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {symptoms.map((symptom) => (
                  <div key={symptom.id} className="p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <p className="font-medium text-gray-900 dark:text-white text-sm">
                        {symptom.symptoms}
                      </p>
                      {symptom.severity && (
                        <Badge variant={symptom.severity === 'high' ? 'destructive' : 'secondary'}>
                          {symptom.severity}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatDate(symptom.created_at)}
                    </div>
                    {symptom.analysis && (
                      <div className="mt-2 p-2 bg-gray-50 dark:bg-gray-700 rounded text-xs">
                        <p className="line-clamp-3">{symptom.analysis.substring(0, 150)}...</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                <Brain className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No symptom analyses yet</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Appointment History */}
        <Card className="bg-white dark:bg-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-green-600" />
              <span>Appointment History</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {appointments.length > 0 ? (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {appointments.map((appointment) => (
                  <div key={appointment.id} className="p-3 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white text-sm">
                          {appointment.doctor_name}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                          {appointment.specialty}
                        </p>
                      </div>
                      <Badge variant={appointment.status === 'confirmed' ? 'default' : 'secondary'}>
                        {appointment.status}
                      </Badge>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                        <Calendar className="h-3 w-3 mr-1" />
                        {appointment.date} at {appointment.time}
                      </div>
                      <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                        <Clock className="h-3 w-3 mr-1" />
                        Booked: {formatDate(appointment.created_at)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                <Stethoscope className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No appointments yet</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProfileSection;
