
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock, User, Mail, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

const AppointmentBooking = () => {
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [isBooking, setIsBooking] = useState(false);
  const { toast } = useToast();

  const doctors = [
    { id: '1', name: 'Dr. Sarah Johnson', specialty: 'General Medicine', avatar: '👩‍⚕️' },
    { id: '2', name: 'Dr. Michael Chen', specialty: 'Cardiology', avatar: '👨‍⚕️' },
    { id: '3', name: 'Dr. Emily Rodriguez', specialty: 'Dermatology', avatar: '👩‍⚕️' },
    { id: '4', name: 'Dr. David Wilson', specialty: 'Pediatrics', avatar: '👨‍⚕️' },
  ];

  const timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
  ];

  const handleBookAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsBooking(true);

    try {
      const doctor = doctors.find(d => d.id === selectedDoctor);
      if (!doctor) throw new Error('Selected doctor not found');

      const formattedDate = formatDate(selectedDate);
      
      // Get current user
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('User not authenticated');

      // Save appointment to database
      const { error: insertError } = await supabase
        .from('appointments')
        .insert({
          user_id: user.user.id,
          doctor_name: doctor.name,
          specialty: doctor.specialty,
          date: formattedDate,
          time: selectedTime,
          status: 'confirmed'
        });

      if (insertError) throw insertError;

      // Call Supabase Edge Function to send confirmation email
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: {
          patientName,
          patientEmail,
          doctorName: doctor.name,
          specialty: doctor.specialty,
          appointmentDate: formattedDate,
          appointmentTime: selectedTime
        }
      });

      if (error) throw error;
      
      toast({
        title: "Appointment Booked!",
        description: "Your appointment has been saved and confirmation email sent.",
      });

      // Reset form
      setSelectedDate('');
      setSelectedTime('');
      setSelectedDoctor('');
      setPatientName('');
      setPatientEmail('');
    } catch (error) {
      console.error('Error booking appointment:', error);
      toast({
        title: "Booking Failed",
        description: "Unable to book appointment. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsBooking(false);
    }
  };

  // Format date to be more readable
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      month: 'long', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  // Generate next 14 days for date selection
  const getAvailableDates = () => {
    const dates = [];
    const today = new Date();
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push({
        value: date.toISOString().split('T')[0],
        label: date.toLocaleDateString('en-US', { 
          weekday: 'long', 
          month: 'short', 
          day: 'numeric' 
        })
      });
    }
    return dates;
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Book an Appointment</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Schedule a consultation with our healthcare professionals
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <Card className="bg-white dark:bg-gray-800 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              <span>Schedule Your Visit</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleBookAppointment} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Patient Information */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-900 dark:text-white">Patient Information</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="patient-name">Full Name</Label>
                    <Input
                      id="patient-name"
                      type="text"
                      placeholder="Enter your full name"
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="patient-email">Email Address</Label>
                    <Input
                      id="patient-email"
                      type="email"
                      placeholder="your.email@example.com"
                      value={patientEmail}
                      onChange={(e) => setPatientEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                {/* Appointment Details */}
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-900 dark:text-white">Appointment Details</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="doctor">Select Doctor</Label>
                    <Select value={selectedDoctor} onValueChange={setSelectedDoctor} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a doctor" />
                      </SelectTrigger>
                      <SelectContent>
                        {doctors.map((doctor) => (
                          <SelectItem key={doctor.id} value={doctor.id}>
                            <div className="flex items-center space-x-2">
                              <span>{doctor.avatar}</span>
                              <div>
                                <div className="font-medium">{doctor.name}</div>
                                <div className="text-sm text-gray-500">{doctor.specialty}</div>
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Preferred Date</Label>
                    <Select value={selectedDate} onValueChange={setSelectedDate} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a date" />
                      </SelectTrigger>
                      <SelectContent>
                        {getAvailableDates().map((date) => (
                          <SelectItem key={date.value} value={date.value}>
                            {date.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time">Preferred Time</Label>
                    <Select value={selectedTime} onValueChange={setSelectedTime} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a time" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeSlots.map((time) => (
                          <SelectItem key={time} value={time}>
                            <div className="flex items-center space-x-2">
                              <Clock className="h-4 w-4" />
                              <span>{time}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Selected Appointment Summary */}
              {selectedDoctor && selectedDate && selectedTime && (
                <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-medium text-blue-900 dark:text-blue-300 mb-2">Appointment Summary</h4>
                  <div className="space-y-1 text-sm text-blue-800 dark:text-blue-400">
                    <p><strong>Doctor:</strong> {doctors.find(d => d.id === selectedDoctor)?.name}</p>
                    <p><strong>Specialty:</strong> {doctors.find(d => d.id === selectedDoctor)?.specialty}</p>
                    <p><strong>Date:</strong> {getAvailableDates().find(d => d.value === selectedDate)?.label}</p>
                    <p><strong>Time:</strong> {selectedTime}</p>
                  </div>
                </div>
              )}

              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800"
                disabled={isBooking}
              >
                {isBooking ? (
                  <>
                    <Mail className="mr-2 h-4 w-4 animate-pulse" />
                    Booking & Sending Email...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Book Appointment
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Doctor Cards */}
        <div className="mt-8 grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {doctors.map((doctor) => (
            <Card key={doctor.id} className="bg-white dark:bg-gray-800 hover:shadow-lg transition-shadow">
              <CardContent className="p-4 text-center">
                <div className="text-4xl mb-2">{doctor.avatar}</div>
                <h3 className="font-semibold text-gray-900 dark:text-white">{doctor.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{doctor.specialty}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AppointmentBooking;
