
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { Calendar, TrendingUp, Activity, Heart } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface HealthData {
  symptoms: any[];
  appointments: any[];
}

const HealthInsights = () => {
  const [healthData, setHealthData] = useState<HealthData>({ symptoms: [], appointments: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHealthData();
  }, []);

  const fetchHealthData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const [symptomsResult, appointmentsResult] = await Promise.all([
        supabase
          .from('symptoms')
          .select('*')
          .eq('user_id', user.user.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('appointments')
          .select('*')
          .eq('user_id', user.user.id)
          .order('created_at', { ascending: false })
      ]);

      setHealthData({
        symptoms: symptomsResult.data || [],
        appointments: appointmentsResult.data || []
      });
    } catch (error) {
      console.error('Error fetching health data:', error);
    } finally {
      setLoading(false);
    }
  };

  const prepareChartData = () => {
    const monthlyData = {};
    const currentDate = new Date();
    
    // Initialize last 6 months
    for (let i = 5; i >= 0; i--) {
      const date = new Date(currentDate);
      date.setMonth(date.getMonth() - i);
      const monthKey = date.toLocaleString('default', { month: 'short', year: 'numeric' });
      monthlyData[monthKey] = { month: monthKey, symptoms: 0, appointments: 0 };
    }

    // Count symptoms by month
    healthData.symptoms.forEach(symptom => {
      const date = new Date(symptom.created_at);
      const monthKey = date.toLocaleString('default', { month: 'short', year: 'numeric' });
      if (monthlyData[monthKey]) {
        monthlyData[monthKey].symptoms++;
      }
    });

    // Count appointments by month
    healthData.appointments.forEach(appointment => {
      const date = new Date(appointment.created_at);
      const monthKey = date.toLocaleString('default', { month: 'short', year: 'numeric' });
      if (monthlyData[monthKey]) {
        monthlyData[monthKey].appointments++;
      }
    });

    return Object.values(monthlyData);
  };

  const prepareSeverityData = () => {
    const severityCount = healthData.symptoms.reduce((acc, symptom) => {
      const severity = symptom.severity || 'mild';
      acc[severity] = (acc[severity] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(severityCount).map(([severity, count]) => ({
      severity,
      count,
      color: severity === 'high' ? '#ef4444' : severity === 'medium' ? '#f59e0b' : '#10b981'
    }));
  };

  const chartConfig = {
    symptoms: {
      label: "Symptoms",
      color: "#3b82f6",
    },
    appointments: {
      label: "Appointments",
      color: "#10b981",
    },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const chartData = prepareChartData();
  const severityData = prepareSeverityData();

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Health Insights</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Track your health journey with visual analytics
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Activity className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{healthData.symptoms.length}</p>
                <p className="text-sm text-gray-600">Total Symptoms</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Calendar className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold">{healthData.appointments.length}</p>
                <p className="text-sm text-gray-600">Appointments</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-red-600" />
              <div>
                <p className="text-2xl font-bold">
                  {healthData.symptoms.filter(s => s.severity === 'high').length}
                </p>
                <p className="text-sm text-gray-600">High Priority</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">
                  {Math.round((healthData.symptoms.length / 6) * 10) / 10}
                </p>
                <p className="text-sm text-gray-600">Avg/Month</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Health Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[300px]">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="symptoms" fill="var(--color-symptoms)" />
                <Bar dataKey="appointments" fill="var(--color-appointments)" />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Symptom Severity Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Symptom Severity Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={severityData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ severity, count }) => `${severity}: ${count}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="count"
                  >
                    {severityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Health Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...healthData.symptoms, ...healthData.appointments]
              .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
              .slice(0, 5)
              .map((item, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 border rounded-lg">
                  <div className={`w-3 h-3 rounded-full ${
                    'symptoms' in item ? 'bg-blue-500' : 'bg-green-500'
                  }`} />
                  <div className="flex-1">
                    <p className="font-medium">
                      {'symptoms' in item ? 'Symptom Analysis' : 'Appointment Booked'}
                    </p>
                    <p className="text-sm text-gray-600">
                      {'symptoms' in item ? item.symptoms : `Dr. ${item.doctor_name}`}
                    </p>
                  </div>
                  <p className="text-sm text-gray-500">
                    {new Date(item.created_at).toLocaleDateString()}
                  </p>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HealthInsights;
