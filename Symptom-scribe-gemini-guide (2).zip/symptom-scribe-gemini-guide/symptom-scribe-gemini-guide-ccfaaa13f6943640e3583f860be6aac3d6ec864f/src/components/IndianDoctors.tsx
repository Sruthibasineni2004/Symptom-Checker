
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { MapPin, Star, Clock, Calendar as CalendarIcon, User } from 'lucide-react';
import { format } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  experience: number;
  rating: number;
  city: string;
  hospital: string;
  consultationFee: number;
  availableSlots: string[];
}

const indianDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Rajesh Kumar',
    specialty: 'Cardiology',
    experience: 15,
    rating: 4.8,
    city: 'Mumbai',
    hospital: 'Lilavati Hospital',
    consultationFee: 1500,
    availableSlots: ['09:00', '10:00', '11:00', '14:00', '15:00']
  },
  {
    id: '2',
    name: 'Dr. Priya Sharma',
    specialty: 'Dermatology',
    experience: 12,
    rating: 4.9,
    city: 'Delhi',
    hospital: 'All India Institute of Medical Sciences',
    consultationFee: 1200,
    availableSlots: ['10:00', '11:00', '12:00', '16:00', '17:00']
  },
  {
    id: '3',
    name: 'Dr. Suresh Gupta',
    specialty: 'Orthopedics',
    experience: 20,
    rating: 4.7,
    city: 'Bangalore',
    hospital: 'Manipal Hospital',
    consultationFee: 1800,
    availableSlots: ['09:00', '10:00', '14:00', '15:00', '16:00']
  },
  {
    id: '4',
    name: 'Dr. Meera Patel',
    specialty: 'Gynecology',
    experience: 18,
    rating: 4.8,
    city: 'Chennai',
    hospital: 'Apollo Hospital',
    consultationFee: 1600,
    availableSlots: ['11:00', '12:00', '14:00', '15:00', '17:00']
  },
  {
    id: '5',
    name: 'Dr. Arun Singh',
    specialty: 'Neurology',
    experience: 22,
    rating: 4.9,
    city: 'Pune',
    hospital: 'Ruby Hall Clinic',
    consultationFee: 2000,
    availableSlots: ['09:00', '10:00', '11:00', '15:00', '16:00']
  },
  {
    id: '6',
    name: 'Dr. Kavita Reddy',
    specialty: 'Pediatrics',
    experience: 14,
    rating: 4.8,
    city: 'Hyderabad',
    hospital: 'Continental Hospitals',
    consultationFee: 1300,
    availableSlots: ['10:00', '11:00', '12:00', '16:00', '17:00']
  }
];

const IndianDoctors = () => {
  const [doctors, setDoctors] = useState<Doctor[]>(indianDoctors);
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>(indianDoctors);
  const [searchCity, setSearchCity] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState('');
  const [booking, setBooking] = useState(false);
  const { toast } = useToast();

  const specialties = [...new Set(doctors.map(doctor => doctor.specialty))];
  const cities = [...new Set(doctors.map(doctor => doctor.city))];

  useEffect(() => {
    filterDoctors();
  }, [searchCity, selectedSpecialty]);

  const filterDoctors = () => {
    let filtered = doctors;

    if (searchCity) {
      filtered = filtered.filter(doctor => 
        doctor.city.toLowerCase().includes(searchCity.toLowerCase())
      );
    }

    if (selectedSpecialty && selectedSpecialty !== 'all') {
      filtered = filtered.filter(doctor => doctor.specialty === selectedSpecialty);
    }

    setFilteredDoctors(filtered);
  };

  const bookAppointment = async () => {
    if (!selectedDoctor || !selectedDate || !selectedTime) {
      toast({
        title: "Missing Information",
        description: "Please select a doctor, date, and time slot.",
        variant: "destructive"
      });
      return;
    }

    setBooking(true);

    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) {
        toast({
          title: "Authentication Required",
          description: "Please log in to book an appointment.",
          variant: "destructive"
        });
        return;
      }

      // Get user profile for name and email
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.user.id)
        .single();

      const appointmentData = {
        user_id: user.user.id,
        doctor_name: selectedDoctor.name,
        specialty: selectedDoctor.specialty,
        date: format(selectedDate, 'yyyy-MM-dd'),
        time: selectedTime,
        status: 'confirmed'
      };

      const { error: appointmentError } = await supabase
        .from('appointments')
        .insert(appointmentData);

      if (appointmentError) throw appointmentError;

      // Send confirmation email
      const emailData = {
        patientName: profile?.name || user.user.email?.split('@')[0] || 'Patient',
        patientEmail: user.user.email,
        doctorName: selectedDoctor.name,
        appointmentDate: format(selectedDate, 'MMMM dd, yyyy'),
        appointmentTime: selectedTime,
        specialty: selectedDoctor.specialty
      };

      const { error: emailError } = await supabase.functions.invoke('send-email', {
        body: emailData
      });

      if (emailError) {
        console.error('Email sending failed:', emailError);
      }

      toast({
        title: "Appointment Booked!",
        description: `Your appointment with ${selectedDoctor.name} has been confirmed for ${format(selectedDate, 'MMM dd, yyyy')} at ${selectedTime}.`,
      });

      // Reset selection
      setSelectedDoctor(null);
      setSelectedDate(undefined);
      setSelectedTime('');

    } catch (error: any) {
      console.error('Booking error:', error);
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to book appointment. Please try again.",
        variant: "destructive"
      });
    } finally {
      setBooking(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Book with Indian Doctors</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Connect with qualified doctors across India
        </p>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Input
            placeholder="Search by city..."
            value={searchCity}
            onChange={(e) => setSearchCity(e.target.value)}
          />
        </div>
        <div>
          <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
            <SelectTrigger>
              <SelectValue placeholder="Select specialty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Specialties</SelectItem>
              {specialties.map(specialty => (
                <SelectItem key={specialty} value={specialty}>{specialty}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Doctors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDoctors.map((doctor) => (
          <Card key={doctor.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{doctor.name}</CardTitle>
                  <p className="text-blue-600 font-medium">{doctor.specialty}</p>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 text-yellow-500 fill-current" />
                  <span className="text-sm font-medium">{doctor.rating}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span>{doctor.city}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <User className="h-4 w-4 text-gray-500" />
                  <span>{doctor.experience} years experience</span>
                </div>
                <div className="text-sm text-gray-600">
                  {doctor.hospital}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Badge variant="secondary">₹{doctor.consultationFee}</Badge>
                <Button
                  size="sm"
                  onClick={() => setSelectedDoctor(doctor)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Book Appointment
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Booking Modal */}
      {selectedDoctor && (
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Book Appointment with {selectedDoctor.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">Select Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <label className="text-sm font-medium">Select Time</label>
              <Select value={selectedTime} onValueChange={setSelectedTime}>
                <SelectTrigger>
                  <SelectValue placeholder="Select time slot" />
                </SelectTrigger>
                <SelectContent>
                  {selectedDoctor.availableSlots.map(slot => (
                    <SelectItem key={slot} value={slot}>{slot}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => setSelectedDoctor(null)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={bookAppointment}
                disabled={booking}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                {booking ? "Booking..." : "Confirm Booking"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default IndianDoctors;
